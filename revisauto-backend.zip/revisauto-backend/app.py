from flask import Flask, jsonify, request
from flask_cors import CORS
from flasgger import Swagger 
import sqlite3
import datetime
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
CORS(app)
swagger = Swagger(app)

def get_db_connection():
    conn = sqlite3.connect('manutencao.db')
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db_connection()
    # Tabela de usuários
    conn.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome_completo TEXT NOT NULL,
            usuario TEXT NOT NULL UNIQUE,
            senha_hash TEXT NOT NULL
        )
    ''')
    # Tabela de manutenções
    conn.execute('''
        CREATE TABLE IF NOT EXISTS manutencoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            tipo TEXT NOT NULL,
            km_atual INTEGER NOT NULL,
            data TEXT NOT NULL,
            observacoes TEXT,
            proxima_km INTEGER,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        )
    ''')
    # Tabela de histórico
    conn.execute('''
        CREATE TABLE IF NOT EXISTS historico (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            manutencao_id INTEGER NOT NULL,
            usuario_id INTEGER NOT NULL,
            acao TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            FOREIGN KEY (manutencao_id) REFERENCES manutencoes(id),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        )
    ''')

    # Cria usuário admin padrão
    admin = conn.execute('SELECT * FROM usuarios WHERE usuario = ?', ('admin',)).fetchone()
    if not admin:
        senha_hash = generate_password_hash('admin')
        conn.execute('''
            INSERT INTO usuarios (nome_completo, usuario, senha_hash)
            VALUES (?, ?, ?)
        ''', ('Administrador', 'admin', senha_hash))
        print('[INFO] Usuário admin criado: admin/admin')

    conn.commit()
    conn.close()


@app.route('/register', methods=['POST'])
def register():
    data = request.json
    nome = data['nome_completo']
    usuario = data['usuario']
    senha = data['senha']
    senha_hash = generate_password_hash(senha)

    conn = get_db_connection()
    try:
        conn.execute('INSERT INTO usuarios (nome_completo, usuario, senha_hash) VALUES (?, ?, ?)',
                     (nome, usuario, senha_hash))
        conn.commit()
        return jsonify({'status': 'registered'}), 201
    except sqlite3.IntegrityError:
        return jsonify({'error': 'Usuário já existe'}), 400
    finally:
        conn.close()


@app.route('/login', methods=['POST'])
def login():
    data = request.json
    usuario = data['usuario']
    senha = data['senha']
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM usuarios WHERE usuario = ?', (usuario,)).fetchone()
    conn.close()
    if user and check_password_hash(user['senha_hash'], senha):
        return jsonify({
            'status': 'success',
            'usuario_id': user['id'],
            'nome_completo': user['nome_completo']
        })
    else:
        return jsonify({'error': 'Usuário ou senha incorretos'}), 401


@app.route('/manutencao', methods=['POST'])
def add_manutencao():
    
    """
Cadastra novo usuário
---
tags:
  - Usuários
requestBody:
  required: true
  content:
    application/json:
      schema:
        type: object
        required:
          - nome_completo
          - usuario
          - senha
        properties:
          nome_completo:
            type: string
            example: Marcelo M. Almeida Jr
          usuario:
            type: string
            example: marcelo
          senha:
            type: string
            example: marcelo
responses:
  201:
    description: Usuário cadastrado com sucesso
"""

"""
Cadastra nova manutenção
---
tags:
  - Manutenções
requestBody:
  required: true
  content:
    application/json:
      schema:
        type: object
        required:
          - usuario_id
          - tipo
          - km_atual
          - data
          - proxima_km
        properties:
          usuario_id:
            type: integer
            example: 1
          tipo:
            type: string
            example: Troca de Velas
          km_atual:
            type: integer
            example: 120
          data:
            type: string
            format: date
            example: 2025-07-06
          observacoes:
            type: string
            example: Originais NGK.
          proxima_km:
            type: integer
            example: 300
responses:
  201:
    description: Manutenção criada com sucesso por Marcelo M. Almeida Jr.
"""

    
    # Rotas
    
    data = request.json
    conn = get_db_connection()
    cur = conn.execute('''
        INSERT INTO manutencoes (usuario_id, tipo, km_atual, data, observacoes, proxima_km)
        VALUES (?, ?, ?, ?, ?, ?)''',
                       (data['usuario_id'], data['tipo'], data['km_atual'], data['data'],
                        data.get('observacoes', ''), data['proxima_km']))
    manut_id = cur.lastrowid
    conn.execute('''INSERT INTO historico (manutencao_id, usuario_id, acao, timestamp)
                    VALUES (?, ?, ?, ?)''',
                 (manut_id, data['usuario_id'], 'Criou manutenção', datetime.datetime.now().isoformat()))
    conn.commit()
    conn.close()
    return jsonify({'status': 'created', 'manutencao_id': manut_id}), 201


@app.route('/manutencoes', methods=['GET'])
def get_manutencoes():
    conn = get_db_connection()
    rows = conn.execute('''
        SELECT m.*, u.nome_completo
        FROM manutencoes m
        JOIN usuarios u ON m.usuario_id = u.id''').fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.route('/manutencao/<int:id>', methods=['GET'])
def get_manutencao(id):
    conn = get_db_connection()
    row = conn.execute('''
        SELECT m.*, u.nome_completo
        FROM manutencoes m
        JOIN usuarios u ON m.usuario_id = u.id
        WHERE m.id = ?''', (id,)).fetchone()
    conn.close()
    if row:
        return jsonify(dict(row))
    return jsonify({'error': 'Not found'}), 404


@app.route('/manutencao/<int:id>', methods=['PUT'])
def update_manutencao(id):
    data = request.json
    conn = get_db_connection()
    conn.execute('''
        UPDATE manutencoes
        SET usuario_id=?, tipo=?, km_atual=?, data=?, observacoes=?, proxima_km=?
        WHERE id = ?''',
                 (data['usuario_id'], data['tipo'], data['km_atual'], data['data'],
                  data.get('observacoes', ''), data['proxima_km'], id))
    conn.execute('''INSERT INTO historico (manutencao_id, usuario_id, acao, timestamp)
                    VALUES (?, ?, ?, ?)''',
                 (id, data['usuario_id'], 'Atualizou manutenção', datetime.datetime.now().isoformat()))
    conn.commit()
    conn.close()
    return jsonify({'status': 'updated'})


@app.route('/manutencao/<int:id>', methods=['DELETE'])
def delete_manutencao(id):
    data = request.json or {}
    usuario_id = data.get('usuario_id')
    conn = get_db_connection()
    conn.execute('DELETE FROM manutencoes WHERE id = ?', (id,))
    if usuario_id:
        conn.execute('''INSERT INTO historico (manutencao_id, usuario_id, acao, timestamp)
                        VALUES (?, ?, ?, ?)''',
                     (id, usuario_id, 'Excluiu manutenção', datetime.datetime.now().isoformat()))
    conn.commit()
    conn.close()
    return jsonify({'status': 'deleted'})


@app.route('/historico/<int:manutencao_id>', methods=['GET'])
def get_historico(manutencao_id):
    conn = get_db_connection()
    rows = conn.execute('''
        SELECT h.*, u.nome_completo
        FROM historico h
        JOIN usuarios u ON h.usuario_id = u.id
        WHERE manutencao_id = ?
        ORDER BY timestamp DESC''', (manutencao_id,)).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


if __name__ == '__main__':
    init_db()
    app.run(debug=True)