@app.route('/manutencao', methods=['POST'])
def add_manutencao():
    """
    Cadastra nova manutenção
    ---
    tags:
      - Manutenções
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            required:
              - usuario_id
              - tipo
              - km_atual
              - data
              - proxima_km
            properties:
              usuario_id:
                type: integer
                example: 1
              tipo:
                type: string
                example: Troca de Velas
              km_atual:
                type: integer
                example: 120
              data:
                type: string
                format: date
                example: 2025-07-06
              observacoes:
                type: string
                example: Originais NGK.
              proxima_km:
                type: integer
                example: 300
    responses:
      201:
        description: Manutenção criada com sucesso por Marcelo M. Almeida Jr.
    """
